"use client";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { useState } from "react";

interface SortControlsProps {
  sortableColumns: string[];
  sortBy: string | null;
  sortDir: "asc" | "desc";
  onSortBy: (col: string | null) => void;
  onSortDir: (dir: "asc" | "desc") => void;
}

export default function SortControls({
  sortableColumns,
  sortBy,
  sortDir,
  onSortBy,
  onSortDir,
}: SortControlsProps) {
  const [search, setSearch] = useState("");

  const filtered = sortableColumns.filter((c) =>
    c.toLowerCase().includes(search.toLowerCase())
  );

  if (sortableColumns.length === 0) return null;

  return (
    <div className="rounded-xl border border-slate-800 overflow-hidden">
      <div className="px-5 py-4 bg-slate-900 border-b border-slate-800 flex items-center gap-3">
        <ArrowUpDown className="w-4 h-4 text-violet-400" />
        <span className="font-semibold text-slate-200 text-sm">Sort Results</span>
        <span className="text-xs text-slate-500">Only Group-by columns and metrics are sortable</span>
      </div>

      <div className="p-4 bg-slate-950 flex flex-wrap gap-4 items-start">
        {/* Sort-by picker */}
        <div className="flex flex-col gap-2">
          <label className="text-xs text-slate-500 uppercase tracking-wider">Sort by</label>
          <input
            type="text"
            placeholder="Search column…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-slate-300 placeholder-slate-600 focus:outline-none focus:border-violet-500 w-52"
          />
          <div className="flex flex-wrap gap-1.5 max-w-xs">
            <button
              onClick={() => onSortBy(null)}
              className={`px-3 py-1.5 rounded-lg border text-xs transition-all ${
                sortBy === null
                  ? "bg-slate-700 border-slate-600 text-slate-200"
                  : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400"
              }`}
            >
              None
            </button>
            {filtered.map((col) => (
              <button
                key={col}
                onClick={() => onSortBy(col)}
                className={`px-3 py-1.5 rounded-lg border text-xs transition-all ${
                  sortBy === col
                    ? "bg-violet-900/60 border-violet-700 text-violet-200"
                    : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-400"
                }`}
              >
                {col}
              </button>
            ))}
          </div>
        </div>

        {/* Direction */}
        {sortBy !== null && (
          <div className="flex flex-col gap-2">
            <label className="text-xs text-slate-500 uppercase tracking-wider">Direction</label>
            <div className="flex gap-2">
              <button
                onClick={() => onSortDir("asc")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm transition-all ${
                  sortDir === "asc"
                    ? "bg-violet-900/60 border-violet-700 text-violet-200"
                    : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700"
                }`}
              >
                <ArrowUp className="w-3.5 h-3.5" /> Ascending
              </button>
              <button
                onClick={() => onSortDir("desc")}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm transition-all ${
                  sortDir === "desc"
                    ? "bg-violet-900/60 border-violet-700 text-violet-200"
                    : "bg-transparent border-slate-800 text-slate-500 hover:border-slate-700"
                }`}
              >
                <ArrowDown className="w-3.5 h-3.5" /> Descending
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
