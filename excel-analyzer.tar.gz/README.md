# Excel Analyzer

A Next.js + Tailwind app to upload, preview, and summarize Excel files.

## Setup

```bash
cd excel-analyzer
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## How it works

1. **Upload** — drag & drop or click to upload any `.xlsx` or `.xls` file
2. **Preview** — the first 10 rows are shown in a collapsible table
3. **Configure columns** — for each column, choose:
   - **Ignore** — not used in summary
   - **Filter** — pick specific values to include (e.g. only Alice's rows)
   - **Group by** — split results by each unique value (e.g. one row per person)
4. **Sort** — sort by any Group-by column or numeric metric, ascending or descending
5. **Summary** — see counts + sums of all numeric columns per group

## Example with the sample data

| Goal | Config |
|---|---|
| Sum of Alice's rows | `Assigned to` → Filter → select Alice |
| Each person's totals | `Assigned to` → Group by |
| Alice's tasks individually | `Assigned to` → Filter → Alice, `Task Name` → Group by |
| All tasks sorted by Days Required desc | `Task Name` → Group by, Sort by `Days Required` desc |

## Stack

- Next.js 14 (App Router)
- Tailwind CSS
- `xlsx` library for Excel parsing
- `lucide-react` for icons
